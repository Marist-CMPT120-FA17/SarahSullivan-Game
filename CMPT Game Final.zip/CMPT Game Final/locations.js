function Item (id, name, description) {
    this.id = id;
    this.name = name;
    this.description = description;	
	this.toString = function () {
		return this.name + " " + this.description;
	}
}
function Location(id, name, description, item) {
    this.id = id;
    this.name = name;
    this.description = description;
    this.item = item;
	this.visited = false;
	this.toString = function() {
		return this.name + " " + this.description + "\n" + ((this.item)?("You can take" + this.item +" from this location and add it to your inventory! Type \"take\" in the command box and click go."):"");
	};
}

var items = [];
items.push(new Item(1, '','self esteem'));
items.push(new Item(2, '','a $20 bill you found on the ground'));
items.push(new Item(3, '','a friend'));
items.push(new Item(4, '','extra fries'));

var locations = [];
locations.push(new Location(1, "You're at home in your room.","Take a nap!", false));
locations.push(new Location(2, "You're now at Lola's.","Try some peanut noodles - I hear they're great!\n", false));
locations.push(new Location(3, "You're at the gym.","Get yourself back in shape!!\n", items[0]));
locations.push(new Location(4, "You're at Tony's Pizza!","AHHH!! Finally some good pizza!\n", false));
locations.push(new Location(5, "Now you're at Taco Bell.","Grab yourself a baja blast!\n", items[1]));
locations.push(new Location(6, "You've made your way to The Caboret.","Use that thrifty and get some popcorn chicken!\n", false));
locations.push(new Location(7, "Lucky you, you're at Rossi's now!","Go enjoy a delicious sandwich!\n", items[2]));
locations.push(new Location(8, "Now you're at Mill House Brewing Company.","Have a flight of beer to celebrate!\n", false));
locations.push(new Location(9, "Unfortunately you ran out of cash and ended up at the Dining Hall.","Enjoy spending a $13 meal swipe on a slice of cardboard pizza...\n", false));
locations.push(new Location(10, "You just arrived at Five Guys. Yum!","Grab a little cheeseburger with some cajun fries!\n", items[3]));

var inventory = [];
//
//  Game Map
//
//  l3
//  l1 l2 l6
//     l4 l5 l7 l8
//	   l9    l10   
//

var map = [
	[ 3, 0, 0, 0,  0],
	[ 1, 2, 6, 0,  0],
	[ 0, 4, 5, 7,  8],
	[ 0, 9, 0, 10, 0]
];
var current_location = [1,0];

function canMove(current_location, move) {
	var next = [current_location[0]+move[0], current_location[1]+move[1]];
	if ( 
	 next[0]>=0 && 
	 next[0]<=map.length-1 && 
	 next[1]>=0 && 
	 next[1]<=map[next[0]].length-1 && 
	 map[next[0]][next[1]]>0
	 )
		return next;
	else	
		return current_location;
}
function addScore() {
	document.getElementById("score").value = parseInt(document.getElementById("score").value) + 5;
}
function isGameWon() {
	return (parseInt(document.getElementById("score").value) >= 50 && inventory.length==items.length);
}
function Won() {
	setTimeout(function () {
		updateDisplay("WINNER!!!! Congrats! You\'ve successfully collected all the inventory and achieved the highest score!\n\n If you wish to play again, please refresh the page.");
		alert("WINNER!!!!!!");
	}, 100);
}
function updateDisplay(message) {
	var game_screen = document.getElementById("game_screen");
	game_screen.value = message;	

	document.getElementById('north').disabled = (canMove(current_location, [-1, 0])==current_location);
	document.getElementById('south').disabled = (canMove(current_location, [ 1, 0])==current_location);
	document.getElementById('east').disabled  = (canMove(current_location, [ 0, 1])==current_location);
	document.getElementById('west').disabled  = (canMove(current_location, [ 0,-1])==current_location);
}
function init() {
	updateDisplay("You are currently at home.\n\nWhere would you like to go?");
}
function move(move) {
	var message = '';
	if (isGameWon()) return;
	
	var newloc = canMove(current_location, move);
	if (newloc != current_location) {
		current_location = newloc;
		var place = map[current_location[0]][current_location[1]];
		if (!locations[place-1].visited) addScore();
		locations[place-1].visited = true;
		message = locations[place-1];
		
		if (isGameWon()) Won();
	} else {
		message = "You cannot go that way";
	}
	updateDisplay(message);
}
function go() {
	if (isGameWon()) return;

	var command = document.getElementById("command").value;
	switch (command.toLowerCase()) {
		case 'n': move([-1, 0]); break;
		case 's': move([ 1, 0]); break;
		case 'e': move([ 0, 1]); break;
		case 'w': move([ 0,-1]); break;
		case 'north': move([-1, 0]); break;
		case 'south': move([ 1, 0]); break;
		case 'east': move([ 0, 1]); break;
		case 'west': move([ 0,-1]); break;
		case 'take': takeCurrentItem(); break;
		case 'i':
		case 'inventory': 
			var message = ''
			if (inventory.length > 0) {
				message = "Current inventory:" + inventory;
				}
			else {
				message = "Inventory is currently empty. Move through locations to take items.";
				}
			updateDisplay(message);
			break;
		case 'help': 
			updateDisplay("*GAME HELP*\n"+
			"Use the navigation buttons or text box to move between locations.\n"+
			"You can use the following commands in the text box: N, S, E, W, HELP, INVENTORY or I, TAKE\n"+
			"You can type commands in either upper or lowercase.\n"+
			"You earn 5 points when you visit each place for the first time.\n"+
			"There are different items in different locations which you can take and add to your inventory.\n\n"+
			"*COMMAND DEFINITIONS*\n"+
			"N - go North\n"+
			"S - go South\n"+
			"E - go East\n"+
			"W - go West\n"+
			"HELP - displays this hepful information!\n"+
			"INVENTORY or I - displays current inventory\n"+
			"TAKE - adds item found at current location to your inventory\n"
			);
			break;
		default:
			updateDisplay("I don't understand your command.\n\n"+
			"You can use the following commands in the text box: N, S, E, W, HELP, INVENTORY or I, TAKE\n\n"+
			"Type \"help\" in command box to see complete game info."
			);
	}
}
function takeCurrentItem() {
	var place = map[current_location[0]][current_location[1]];
	if (locations[place-1].item) {
		inventory.push(locations[place-1].item);
		updateDisplay("Added to inventory:"+locations[place-1].item); 
		locations[place-1].item = false;
		
	if (isGameWon()) Won();
	} else {
		updateDisplay("There is nothing to take here"); 
	}
}